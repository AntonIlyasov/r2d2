#!/usr/bin/env python

import rospy
from std_msgs.msg import Int32
import os
import subprocess

save_cmd_flag = False
save_cmd_code = 10
video_cnt = 0
cmd = "/home/firefly/gst_bash/save_video.sh"


def start_save_video():
	print("\n\nRETURN FROM START_SAVE_VIDEO\n\n")
	os.environ["VIK_VIDEO_FILENAME"] = "output_" + str(video_cnt) + ".flv"
	p = subprocess.Popen("exec " + cmd, stdout=subprocess.PIPE, shell=True)
	# print(subprocess.run(["/home/firefly/gst_bash/save_video.sh"], shell=True))   
	print("\n\nRETURN FROM START_SAVE_VIDEO\n\n")
	global video_cnt
	video_cnt+=1
	return

def callback(data):
	rospy.loginfo("Получено число: %d", data.data)
	if data.data == save_cmd_code:
		global save_cmd_flag 
		save_cmd_flag = True
		start_save_video()
	
	# Здесь можно добавить логику обработки полученного числа

def listener():
	rospy.init_node('tof_cam_control_listener', anonymous=True)
	rospy.Subscriber('/toTofCamControl', Int32, callback)

	rate = rospy.Rate(100)
	while not rospy.is_shutdown():
		if save_cmd_flag == True:
			start_save_video()
		rate.sleep()
if __name__ == '__main__':
	try:
		listener()
	except rospy.ROSInterruptException:
		pass
